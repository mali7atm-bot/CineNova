package com.cinenova.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Ink = Color(0xFF080B14)
private val Panel = Color(0xFF121827)
private val Gold = Color(0xFFFFC857)
private val Muted = Color(0xFF9AA4B7)

data class Film(
    val id: Int, val title: String, val genre: String, val year: String,
    val rating: String, val description: String, val colors: List<Color>, val symbol: String
)

private val films = listOf(
    Film(1, "مدينة الظلال", "أكشن • خيال علمي", "2026", "8.9",
        "في مدينة لا تنام، يكتشف شاب سرّاً يغيّر مستقبل العالم.", listOf(Color(0xFF193B55), Color(0xFF7A3D58)), "🌃"),
    Film(2, "آخر مجرة", "مغامرة • خيال علمي", "2025", "9.1",
        "رحلة استكشافية تقود طاقماً إلى أبعد نقطة في الفضاء.", listOf(Color(0xFF34215D), Color(0xFF167B91)), "🚀"),
    Film(3, "اللغز الأخير", "غموض • إثارة", "2024", "8.5",
        "رسالة مجهولة تفتح ملف قضية ظن الجميع أنها انتهت.", listOf(Color(0xFF4A2637), Color(0xFFB06A43)), "🕵️"),
    Film(4, "مملكة التنين", "فانتازيا • مغامرة", "2026", "9.3",
        "فارس صغير يجد خريطة تقوده إلى مملكة أسطورية.", listOf(Color(0xFF174A3B), Color(0xFFB17A35)), "🐉"),
    Film(5, "سباق الصفر", "رياضة • أكشن", "2025", "8.2",
        "متسابق موهوب يخوض أهم تحدٍ في حياته.", listOf(Color(0xFF63321F), Color(0xFFB43D46)), "🏎️"),
    Film(6, "قلب المحيط", "دراما • مغامرة", "2023", "8.7",
        "أصدقاء في رحلة بحرية يكتشفون حكاية منسية.", listOf(Color(0xFF123C58), Color(0xFF27A4A0)), "🌊")
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { CineNovaApp() }
    }
}

@Composable
fun CineNovaApp() {
    var selectedTab by remember { mutableStateOf("الرئيسية") }
    var selectedFilm by remember { mutableStateOf<Film?>(null) }
    var query by remember { mutableStateOf("") }
    var category by remember { mutableStateOf("الكل") }
    val favorites = remember { mutableStateListOf<Int>() }

    MaterialTheme(
        colorScheme = darkColorScheme(
            background = Ink, surface = Panel, primary = Gold,
            onBackground = Color.White, onSurface = Color.White
        )
    ) {
        Surface(modifier = Modifier.fillMaxSize(), color = Ink) {
            if (selectedFilm != null) {
                FilmDetails(selectedFilm!!, favorites.contains(selectedFilm!!.id),
                    onBack = { selectedFilm = null },
                    onFavorite = {
                        val id = selectedFilm!!.id
                        if (favorites.contains(id)) favorites.remove(id) else favorites.add(id)
                    })
            } else {
                Column(Modifier.fillMaxSize()) {
                    when (selectedTab) {
                        "البحث" -> SearchScreen(query, { query = it }, films.filter {
                            it.title.contains(query, true) || it.genre.contains(query, true)
                        }, { selectedFilm = it })
                        "مفضلتي" -> FavoritesScreen(films.filter { favorites.contains(it.id) }, { selectedFilm = it })
                        "حسابي" -> ProfileScreen()
                        else -> HomeScreen(category, { category = it }, favorites, { id ->
                            if (favorites.contains(id)) favorites.remove(id) else favorites.add(id)
                        }, { selectedFilm = it })
                    }
                    Spacer(Modifier.weight(1f))
                    NavigationBar(containerColor = Panel, contentColor = Muted) {
                        listOf(
                            Triple("الرئيسية", Icons.Default.Home, "الرئيسية"),
                            Triple("البحث", Icons.Default.Search, "البحث"),
                            Triple("مفضلتي", Icons.Default.Bookmark, "مفضلتي"),
                            Triple("حسابي", Icons.Default.Person, "حسابي")
                        ).forEach { (label, icon, key) ->
                            NavigationBarItem(
                                selected = selectedTab == key,
                                onClick = { selectedTab = key },
                                icon = { Icon(icon, contentDescription = label) },
                                label = { Text(label, fontSize = 10.sp) },
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = Gold, selectedTextColor = Gold,
                                    indicatorColor = Color(0xFF343044), unselectedIconColor = Muted,
                                    unselectedTextColor = Muted
                                )
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun HomeScreen(category: String, onCategory: (String) -> Unit, favorites: List<Int>,
               onFavorite: (Int) -> Unit, onOpen: (Film) -> Unit) {
    val categories = listOf("الكل", "أكشن", "مغامرة", "خيال علمي", "غموض")
    val visible = films.filter { category == "الكل" || it.genre.contains(category) }
    LazyColumn(contentPadding = PaddingValues(bottom = 18.dp)) {
        item {
            Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 18.dp),
                verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("CINENOVA", color = Gold, fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 3.sp)
                    Text("عالمك السينمائي", color = Color.White, fontSize = 23.sp, fontWeight = FontWeight.ExtraBold)
                }
                Text("✦", color = Gold, fontSize = 30.sp)
            }
        }
        item {
            Column(Modifier.padding(horizontal = 18.dp)) {
                Text("اختيار اليوم", color = Muted, fontSize = 13.sp)
                Spacer(Modifier.height(10.dp))
                FeaturedFilm(films[3], onClick = { onOpen(films[3]) })
            }
        }
        item {
            Text("اكتشف حسب النوع", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(start = 20.dp, top = 24.dp, bottom = 12.dp))
            Row(Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                categories.forEach { item ->
                    FilterChip(selected = category == item, onClick = { onCategory(item) },
                        label = { Text(item) }, colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = Gold, selectedLabelColor = Ink,
                            containerColor = Panel, labelColor = Color.White))
                }
            }
        }
        item {
            Text("الأكثر مشاهدة", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(start = 20.dp, top = 22.dp, bottom = 12.dp))
        }
        items(visible) { film ->
            FilmRow(film, favorites.contains(film.id), { onFavorite(film.id) }, { onOpen(film) })
        }
    }
}

@Composable
fun FeaturedFilm(film: Film, onClick: () -> Unit) {
    Box(Modifier.fillMaxWidth().height(210.dp).clip(RoundedCornerShape(24.dp))
        .background(Brush.linearGradient(film.colors)).clickable { onClick() }.padding(20.dp)) {
        Column(Modifier.align(Alignment.BottomStart)) {
            Text("CINENOVA ORIGINAL", color=Gold, fontSize=10.sp, fontWeight=FontWeight.Bold, letterSpacing=2.sp)
            Text(film.title, color=Color.White, fontSize=27.sp, fontWeight=FontWeight.ExtraBold)
            Text("${film.genre}   •   ⭐ ${film.rating}", color=Color.White.copy(alpha=.85f), fontSize=12.sp)
            Spacer(Modifier.height(10.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Surface(color=Gold, shape=RoundedCornerShape(30.dp)) {
                    Row(Modifier.padding(horizontal=15.dp, vertical=7.dp), verticalAlignment=Alignment.CenterVertically) {
                        Icon(Icons.Default.PlayArrow, null, tint=Ink, modifier=Modifier.size(18.dp))
                        Text("التفاصيل", color=Ink, fontWeight=FontWeight.Bold, fontSize=12.sp)
                    }
                }
            }
        }
        Text(film.symbol, fontSize=58.sp, modifier=Modifier.align(Alignment.TopEnd).padding(12.dp))
    }
}

@Composable
fun FilmRow(film: Film, favorite: Boolean, onFavorite: () -> Unit, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().padding(horizontal=18.dp, vertical=6.dp)
        .clip(RoundedCornerShape(18.dp)).background(Panel).clickable { onClick() }.padding(10.dp),
        verticalAlignment=Alignment.CenterVertically) {
        Box(Modifier.size(width=82.dp, height=96.dp).clip(RoundedCornerShape(13.dp))
            .background(Brush.linearGradient(film.colors)), contentAlignment=Alignment.Center) {
            Text(film.symbol, fontSize=34.sp)
        }
        Column(Modifier.weight(1f).padding(horizontal=12.dp)) {
            Text(film.title, color=Color.White, fontWeight=FontWeight.Bold, fontSize=16.sp)
            Text(film.genre, color=Muted, fontSize=11.sp, modifier=Modifier.padding(top=5.dp))
            Text("${film.year}  •  ⭐ ${film.rating}", color=Gold, fontSize=11.sp,
                modifier=Modifier.padding(top=8.dp))
        }
        IconButton(onClick=onFavorite) {
            Icon(if (favorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                contentDescription="المفضلة", tint=if (favorite) Color(0xFFFF647C) else Muted)
        }
    }
}

@Composable
fun SearchScreen(query: String, onQuery: (String) -> Unit, results: List<Film>, onOpen: (Film) -> Unit) {
    Column(Modifier.fillMaxSize()) {
        Text("ابحث عن فيلمك", color=Color.White, fontSize=24.sp, fontWeight=FontWeight.Bold,
            modifier=Modifier.padding(20.dp))
        OutlinedTextField(value=query, onValueChange=onQuery, modifier=Modifier.fillMaxWidth().padding(horizontal=18.dp),
            placeholder={ Text("اسم الفيلم أو النوع...") }, leadingIcon={ Icon(Icons.Default.Search, null) },
            singleLine=true, shape=RoundedCornerShape(16.dp), colors=OutlinedTextFieldDefaults.colors(
                focusedBorderColor=Gold, unfocusedBorderColor=Color(0xFF30394A), focusedTextColor=Color.White,
                unfocusedTextColor=Color.White, cursorColor=Gold))
        if (results.isEmpty()) Text("ما لقينا نتائج. جرّب كلمة ثانية.", color=Muted, modifier=Modifier.padding(22.dp))
        else LazyColumn { items(results) { FilmRow(it, false, {}, { onOpen(it) }) } }
    }
}

@Composable
fun FavoritesScreen(favorites: List<Film>, onOpen: (Film) -> Unit) {
    Column(Modifier.fillMaxSize()) {
        Text("قائمة مفضلتي", color=Color.White, fontSize=24.sp, fontWeight=FontWeight.Bold,
            modifier=Modifier.padding(20.dp))
        if (favorites.isEmpty()) Text("الأفلام التي تضيفها للمفضلة ستظهر هنا.", color=Muted,
            modifier=Modifier.padding(20.dp))
        else LazyColumn { items(favorites) { FilmRow(it, true, {}, { onOpen(it) }) } }
    }
}

@Composable
fun ProfileScreen() {
    Column(Modifier.fillMaxSize().padding(22.dp), verticalArrangement=Arrangement.Center,
        horizontalAlignment=Alignment.CenterHorizontally) {
        Text("🎬", fontSize=58.sp)
        Text("مرحباً بك في CineNova", color=Color.White, fontSize=21.sp, fontWeight=FontWeight.Bold)
        Text("نسخة تجريبية • قريباً مزايا أكثر", color=Muted, modifier=Modifier.padding(top=8.dp))
    }
}

@Composable
fun FilmDetails(film: Film, favorite: Boolean, onBack: () -> Unit, onFavorite: () -> Unit) {
    Column(Modifier.fillMaxSize()) {
        Box(Modifier.fillMaxWidth().height(300.dp).background(Brush.linearGradient(film.colors))) {
            Text("رجوع", color=Color.White, modifier=Modifier.align(Alignment.TopStart).padding(20.dp)
                .clip(RoundedCornerShape(12.dp)).background(Color.Black.copy(alpha=.35f))
                .clickable { onBack() }.padding(horizontal=14.dp, vertical=9.dp))
            Text(film.symbol, fontSize=100.sp, modifier=Modifier.align(Alignment.Center))
            Text(film.title, color=Color.White, fontSize=28.sp, fontWeight=FontWeight.ExtraBold,
                modifier=Modifier.align(Alignment.BottomStart).padding(22.dp))
        }
        Column(Modifier.padding(22.dp)) {
            Text("${film.year}   •   ${film.genre}", color=Muted, fontSize=13.sp)
            Text("⭐ ${film.rating} / 10", color=Gold, fontWeight=FontWeight.Bold,
                modifier=Modifier.padding(top=12.dp))
            Text("القصة", color=Color.White, fontSize=18.sp, fontWeight=FontWeight.Bold,
                modifier=Modifier.padding(top=22.dp, bottom=8.dp))
            Text(film.description, color=Muted, fontSize=14.sp, lineHeight=23.sp)
            Spacer(Modifier.height(24.dp))
            Button(onClick=onFavorite, modifier=Modifier.fillMaxWidth(),
                colors=ButtonDefaults.buttonColors(containerColor=Gold, contentColor=Ink),
                shape=RoundedCornerShape(14.dp)) {
                Icon(if (favorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder, null)
                Spacer(Modifier.width(8.dp))
                Text(if (favorite) "إزالة من المفضلة" else "أضف إلى المفضلة", fontWeight=FontWeight.Bold)
            }
            Text("ملاحظة: هذه نسخة تجريبية لعرض واجهة التطبيق، ولا تحتوي على بث أفلام.", color=Muted,
                fontSize=11.sp, modifier=Modifier.padding(top=18.dp))
        }
    }
}
